package com.vault.photos;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.LruCache;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;
    private static final int COLUMNS = 3;

    private final List<File> photos = new ArrayList<>();
    private final ExecutorService io = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private LruCache<String, Bitmap> cache;
    private PhotoAdapter adapter;
    private TextView count, empty;
    private LinearLayout chips;
    private int cell;

    /** Which tab is open: null = All, "" = Unsorted, otherwise a category name. */
    private String current = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Hides the vault from the recent-apps preview and blocks screenshots.
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null && savedInstanceState.containsKey("current")) {
            current = savedInstanceState.getString("current");
        }

        int cacheKb = (int) (Runtime.getRuntime().maxMemory() / 1024 / 8);
        cache = new LruCache<String, Bitmap>(cacheKb) {
            @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount() / 1024; }
        };

        int spacing = dp(2);
        int width = getResources().getDisplayMetrics().widthPixels;
        cell = (width - spacing * (COLUMNS - 1)) / COLUMNS;

        GridView grid = findViewById(R.id.grid);
        grid.setNumColumns(COLUMNS);
        grid.setHorizontalSpacing(spacing);
        grid.setVerticalSpacing(spacing);
        empty = findViewById(R.id.empty);
        grid.setEmptyView(empty);
        adapter = new PhotoAdapter();
        grid.setAdapter(adapter);

        grid.setOnItemClickListener((p, v, pos, id) -> {
            Intent i = new Intent(this, ViewerActivity.class);
            i.putExtra("path", photos.get(pos).getPath());
            if (current != null) i.putExtra("category", current);
            startActivity(i);
        });
        grid.setOnItemLongClickListener((p, v, pos, id) -> {
            photoMenu(photos.get(pos));
            return true;
        });

        count = findViewById(R.id.count);
        chips = findViewById(R.id.chips);
        findViewById(R.id.add).setOnClickListener(v -> pick());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (current != null) out.putString("current", current);
    }

    @Override
    protected void onResume() {
        super.onResume();
        reload();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void reload() {
        // If the open category was removed, fall back to All.
        if (current != null && !current.isEmpty() && !Vault.categories(this).contains(current)) current = null;

        photos.clear();
        photos.addAll(Vault.list(this, current));
        adapter.notifyDataSetChanged();

        int n = photos.size();
        count.setText(n == 1 ? "1 photo" : n + " photos");
        if (current == null) empty.setText("No photos yet.\nTap + to add some.");
        else empty.setText("Nothing in " + label(current) + " yet.\nTap + to add photos here.");
        buildChips();
    }

    private static String label(String category) {
        return category == null ? "All" : category.isEmpty() ? "Unsorted" : category;
    }

    // ---------- category tabs ----------

    private void buildChips() {
        chips.removeAllViews();
        addChip("All", null);
        addChip("Unsorted", "");
        for (String cat : Vault.categories(this)) addChip(cat, cat);

        TextView add = makeChip("+ New", false);
        add.setOnClickListener(v -> CategoryDialogs.askName(this, "New category", "", null, name -> {
            if (Vault.createCategory(this, name)) {
                current = name;
                reload();
            }
        }));
        chips.addView(add);
    }

    private void addChip(String text, String category) {
        boolean selected = current == null ? category == null : current.equals(category);
        TextView chip = makeChip(text, selected);
        chip.setOnClickListener(v -> {
            current = category;
            reload();
        });
        if (category != null && !category.isEmpty()) {
            chip.setOnLongClickListener(v -> {
                categoryMenu(category);
                return true;
            });
        }
        chips.addView(chip);
    }

    private TextView makeChip(String text, boolean selected) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setPadding(dp(16), dp(8), dp(16), dp(8));
        t.setBackgroundResource(selected ? R.drawable.chip_selected : R.drawable.chip);
        t.setTextColor(getColor(selected ? R.color.bg : R.color.text));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(dp(8));
        t.setLayoutParams(lp);
        return t;
    }

    private void categoryMenu(String category) {
        new AlertDialog.Builder(this)
                .setTitle(category)
                .setItems(new String[]{"Rename", "Delete category"}, (d, which) -> {
                    if (which == 0) {
                        CategoryDialogs.askName(this, "Rename category", category, category, name -> {
                            if (Vault.renameCategory(this, category, name)) {
                                cache.evictAll();
                                if (category.equals(current)) current = name;
                                reload();
                            }
                        });
                    } else {
                        new AlertDialog.Builder(this)
                                .setTitle("Delete \"" + category + "\"?")
                                .setMessage("The photos in it won't be deleted. They move to Unsorted.")
                                .setPositiveButton("Delete", (d2, w2) -> {
                                    Vault.deleteCategory(this, category);
                                    cache.evictAll();
                                    if (category.equals(current)) current = null;
                                    reload();
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    }
                })
                .show();
    }

    // ---------- photos ----------

    private void photoMenu(File f) {
        new AlertDialog.Builder(this)
                .setItems(new String[]{"Move to category", "Delete"}, (d, which) -> {
                    if (which == 0) {
                        CategoryDialogs.pickCategory(this, Vault.categoryOf(this, f), cat -> {
                            Vault.move(this, f, cat);
                            cache.remove(f.getPath());
                            Toast.makeText(this, "Moved to " + label(cat), Toast.LENGTH_SHORT).show();
                            reload();
                        });
                    } else {
                        confirmDelete(f);
                    }
                })
                .show();
    }

    private void pick() {
        Intent i;
        if (Build.VERSION.SDK_INT >= 33) {
            // Android's own photo picker: no permissions needed.
            i = new Intent(MediaStore.ACTION_PICK_IMAGES);
            i.putExtra(MediaStore.EXTRA_PICK_IMAGES_MAX, 100);
        } else {
            i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        }
        try {
            startActivityForResult(i, REQ_PICK);
        } catch (Exception e) {
            Toast.makeText(this, "No photo picker found on this phone", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return;

        List<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int k = 0; k < clip.getItemCount(); k++) uris.add(clip.getItemAt(k).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) return;

        // New photos go into the open category (Unsorted when "All" is open).
        final String target = current == null ? "" : current;
        count.setText("Adding " + uris.size() + "…");
        io.execute(() -> {
            int ok = 0;
            for (int k = 0; k < uris.size(); k++) if (Vault.importPhoto(this, uris.get(k), k, target)) ok++;
            final int added = ok, failed = uris.size() - ok;
            main.post(() -> {
                reload();
                String msg = (added == 1 ? "Added 1 photo" : "Added " + added + " photos") + " to " + label(target);
                if (failed > 0) msg += " (" + failed + " failed)";
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
            });
        });
    }

    private void confirmDelete(File f) {
        new AlertDialog.Builder(this)
                .setTitle("Delete photo?")
                .setMessage("It will be removed from the vault for good.")
                .setPositiveButton("Delete", (d, w) -> {
                    f.delete();
                    cache.remove(f.getPath());
                    reload();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private class PhotoAdapter extends BaseAdapter {
        @Override public int getCount() { return photos.size(); }
        @Override public Object getItem(int pos) { return photos.get(pos); }
        @Override public long getItemId(int pos) { return pos; }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            ImageView iv = convertView instanceof ImageView ? (ImageView) convertView : new ImageView(MainActivity.this);
            iv.setLayoutParams(new AbsListView.LayoutParams(cell, cell));
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackgroundColor(0xFF1A1D24);

            File f = photos.get(pos);
            String key = f.getPath();
            iv.setTag(key);
            Bitmap cached = cache.get(key);
            if (cached != null) {
                iv.setImageBitmap(cached);
            } else {
                iv.setImageDrawable(null);
                io.execute(() -> {
                    Bitmap b = Vault.decode(f, cell, cell);
                    if (b != null) cache.put(key, b);
                    main.post(() -> { if (key.equals(iv.getTag())) iv.setImageBitmap(b); });
                });
            }
            return iv;
        }
    }
}
