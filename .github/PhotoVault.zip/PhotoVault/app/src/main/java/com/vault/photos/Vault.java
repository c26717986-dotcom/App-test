package com.vault.photos;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Everything about where photos live and how they're loaded.
 *
 * Layout on disk (private to the app):
 *   files/photos/            <- "Unsorted" photos
 *   files/photos/<Category>/ <- one folder per category
 */
final class Vault {
    private Vault() {}

    /** The app's private photo folder. Only this app can read it. */
    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "photos");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** Folder for a category. Empty or null means Unsorted. */
    static File folder(Context c, String category) {
        if (category == null || category.isEmpty()) return dir(c);
        File d = new File(dir(c), category);
        if (!d.exists()) d.mkdirs();
        return d;
    }

    /** All category names, A to Z. */
    static List<String> categories(Context c) {
        File[] dirs = dir(c).listFiles(File::isDirectory);
        List<String> out = new ArrayList<>();
        if (dirs == null) return out;
        for (File d : dirs) out.add(d.getName());
        out.sort(String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /**
     * Photos, newest first.
     * category null = every photo, "" = Unsorted only, otherwise that category.
     */
    static List<File> list(Context c, String category) {
        List<File> out = new ArrayList<>();
        if (category == null) {
            addFiles(dir(c), out);
            for (String cat : categories(c)) addFiles(new File(dir(c), cat), out);
        } else {
            addFiles(folder(c, category), out);
        }
        out.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return out;
    }

    private static void addFiles(File d, List<File> out) {
        File[] files = d.listFiles(File::isFile);
        if (files != null) out.addAll(Arrays.asList(files));
    }

    /** The category a photo is in ("" for Unsorted). */
    static String categoryOf(Context c, File f) {
        File parent = f.getParentFile();
        return parent == null || parent.equals(dir(c)) ? "" : parent.getName();
    }

    /** Returns an error message, or null if the name is fine. */
    static String checkName(Context c, String name, String ignore) {
        if (name.isEmpty()) return "Write a name first";
        if (name.length() > 30) return "Name is too long";
        if (name.contains("/") || name.contains("\\") || name.startsWith(".")) return "Name can't use / \\ or start with .";
        for (String existing : categories(c)) {
            if (existing.equalsIgnoreCase(name) && !existing.equals(ignore)) return "That category already exists";
        }
        return null;
    }

    static boolean createCategory(Context c, String name) {
        return new File(dir(c), name).mkdirs();
    }

    static boolean renameCategory(Context c, String from, String to) {
        return new File(dir(c), from).renameTo(new File(dir(c), to));
    }

    /** Deletes a category folder. Its photos move to Unsorted, nothing is lost. */
    static void deleteCategory(Context c, String name) {
        File d = new File(dir(c), name);
        File[] files = d.listFiles(File::isFile);
        if (files != null) for (File f : files) move(c, f, "");
        d.delete();
    }

    /** Moves a photo into a category. Returns the photo's new location. */
    static File move(Context c, File f, String category) {
        File target = new File(folder(c, category), f.getName());
        if (target.equals(f)) return f;
        if (target.exists()) target = new File(folder(c, category), System.currentTimeMillis() + "_" + f.getName());
        long time = f.lastModified();
        if (!f.renameTo(target)) return f;
        target.setLastModified(time); // keep its place in the newest-first order
        return target;
    }

    /** Copies one picked photo into the vault. Returns true on success. */
    static boolean importPhoto(Context c, Uri uri, int n, String category) {
        ContentResolver cr = c.getContentResolver();
        String mime = cr.getType(uri);
        String ext = ".jpg";
        if (mime != null) {
            if (mime.contains("png")) ext = ".png";
            else if (mime.contains("webp")) ext = ".webp";
            else if (mime.contains("gif")) ext = ".gif";
            else if (mime.contains("heic") || mime.contains("heif")) ext = ".heic";
        }
        File out = new File(folder(c, category), System.currentTimeMillis() + "_" + n + ext);
        try (InputStream in = cr.openInputStream(uri);
             OutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new Exception("no stream");
            byte[] buf = new byte[64 * 1024];
            int r;
            while ((r = in.read(buf)) != -1) os.write(buf, 0, r);
            return true;
        } catch (Exception e) {
            out.delete();
            return false;
        }
    }

    /** Loads a photo scaled down to roughly the requested size, rotated upright. */
    static Bitmap decode(File f, int reqW, int reqH) {
        String path = f.getPath();
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0 || o.outHeight <= 0) return null;

        int sample = 1;
        while (o.outWidth / (sample * 2) >= reqW && o.outHeight / (sample * 2) >= reqH) sample *= 2;

        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        Bitmap b = BitmapFactory.decodeFile(path, o2);
        if (b == null) return null;

        int rot = rotation(path);
        if (rot == 0) return b;
        Matrix m = new Matrix();
        m.postRotate(rot);
        Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
        if (r != b) b.recycle();
        return r;
    }

    private static int rotation(String path) {
        try {
            ExifInterface e = new ExifInterface(path);
            switch (e.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                case ExifInterface.ORIENTATION_ROTATE_90: return 90;
                case ExifInterface.ORIENTATION_ROTATE_180: return 180;
                case ExifInterface.ORIENTATION_ROTATE_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }
}
