package com.vault.photos;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Full-screen view. Swipe left/right to browse, tap to hide the bar. */
public class ViewerActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private List<File> photos;
    private String category; // null = browsing All
    private int index;
    private int loadToken;
    private ImageView image;
    private View bar;
    private TextView pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_viewer);

        image = findViewById(R.id.image);
        bar = findViewById(R.id.bar);
        pos = findViewById(R.id.pos);

        category = getIntent().hasExtra("category") ? getIntent().getStringExtra("category") : null;
        photos = Vault.list(this, category);
        if (photos.isEmpty()) { finish(); return; }
        String path = getIntent().getStringExtra("path");
        for (int i = 0; i < photos.size(); i++) {
            if (photos.get(i).getPath().equals(path)) { index = i; break; }
        }

        findViewById(R.id.back).setOnClickListener(v -> finish());
        findViewById(R.id.move).setOnClickListener(v -> movePhoto());
        findViewById(R.id.delete).setOnClickListener(v -> confirmDelete());

        GestureDetector gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                bar.setVisibility(bar.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                return true;
            }

            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > 120 && Math.abs(dx) > Math.abs(dy)) {
                    show(dx < 0 ? index + 1 : index - 1);
                    return true;
                }
                return false;
            }
        });
        image.setOnTouchListener((v, e) -> gd.onTouchEvent(e));

        show(index);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    private void show(int i) {
        if (i < 0 || i >= photos.size()) return;
        index = i;
        String where = Vault.categoryOf(this, photos.get(i));
        pos.setText((i + 1) + " / " + photos.size() + "\n" + (where.isEmpty() ? "Unsorted" : where));
        final int token = ++loadToken;
        final File f = photos.get(i);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        io.execute(() -> {
            Bitmap b = Vault.decode(f, dm.widthPixels, dm.heightPixels);
            main.post(() -> { if (token == loadToken) image.setImageBitmap(b); });
        });
    }

    private void movePhoto() {
        File f = photos.get(index);
        CategoryDialogs.pickCategory(this, Vault.categoryOf(this, f), cat -> {
            File moved = Vault.move(this, f, cat);
            Toast.makeText(this, "Moved to " + (cat.isEmpty() ? "Unsorted" : cat), Toast.LENGTH_SHORT).show();
            if (category == null) {
                // Browsing All: the photo stays in the list, just in a new place.
                photos.set(index, moved);
                show(index);
            } else {
                // Browsing one category: the photo has left it.
                removeCurrent();
            }
        });
    }

    private void removeCurrent() {
        photos.remove(index);
        if (photos.isEmpty()) { finish(); return; }
        show(Math.min(index, photos.size() - 1));
    }

    private void confirmDelete() {
        new AlertDialog.Builder(this)
                .setTitle("Delete photo?")
                .setMessage("It will be removed from the vault for good.")
                .setPositiveButton("Delete", (d, w) -> {
                    photos.get(index).delete();
                    removeCurrent();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}
