package com.vault.photos;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Small dialogs shared by the grid and the full-screen viewer. */
final class CategoryDialogs {
    private CategoryDialogs() {}

    /**
     * Asks which category to move to. "" means Unsorted.
     * The photo's current category is left out of the list.
     */
    static void pickCategory(Activity a, String current, Consumer<String> onPicked) {
        List<String> values = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        if (!"".equals(current)) { values.add(""); labels.add("Unsorted"); }
        for (String cat : Vault.categories(a)) {
            if (!cat.equals(current)) { values.add(cat); labels.add(cat); }
        }
        labels.add("+ New category…");

        new AlertDialog.Builder(a)
                .setTitle("Move to")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    if (which < values.size()) {
                        onPicked.accept(values.get(which));
                    } else {
                        askName(a, "New category", "", null, name -> {
                            if (Vault.createCategory(a, name)) onPicked.accept(name);
                        });
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    /** Asks for a category name and checks it. ignore = the name being renamed. */
    static void askName(Activity a, String title, String initial, String ignore, Consumer<String> onName) {
        EditText input = new EditText(a);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setHint("e.g. Travel, Memes, Game art");
        input.setText(initial);
        input.setSelection(initial.length());

        FrameLayout box = new FrameLayout(a);
        int pad = Math.round(20 * a.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);
        box.addView(input);

        AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle(title)
                .setView(box)
                .setPositiveButton("Save", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String name = input.getText().toString().trim();
            String err = Vault.checkName(a, name, ignore);
            if (err != null) {
                Toast.makeText(a, err, Toast.LENGTH_SHORT).show();
                return;
            }
            dialog.dismiss();
            onName.accept(name);
        }));
        dialog.show();
    }
}
